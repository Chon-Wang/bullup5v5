$.getScript('http://github.com/jquery/jquery- color', function () {
	$('body').animate({
		'background-color': '#fff'
	}, 'slow');
});
