//队伍的模拟数据，用于加载swig_battle.html模板
var teams = [
	{
		teamName: 'myTeam',
		type: '3',
		rule: 1,
		bet: 30
	},
	{
		teamName: 'your Team',
		type: '4',
		rule: 1,
		bet: 30
	}
];


//排行榜的模拟数据
var rank_lists = {
	wealth_ranked_list: [
		{
			name: '123',
			wealth: 3000,
			//cap: 3029
		},
		{
			name: 'fefe',
			wealth: 3000,
			cap: 3029
		}
	],

	cap_ranked_list: [
		{
			name: 'wfwf',
			wealth: 3000,
			cap: 3029
		},
		{
			name: 'fedfdffe',
			wealth: 33000,
			cap: 3029
		}
	]
};
