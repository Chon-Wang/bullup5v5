$('#invite-btn').click(function() {
	$('#team-detail-modal').modal('close');
	$('.modal-overlay').remove();
});

$('#hide-btn').click(function() {
	$('#waiting-modal').modal('close');
	$('.modal-overlay').remove();
});
