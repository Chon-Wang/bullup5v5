function createPagination(beforeElementId, totalPage, reloadFunction){
	/* 
	   function for create pagination on pages
	   Parameters---
	   totalpage: max page number
	   reloadFunction: a function for loading the page with new data
	*/

	
	
}
