$('.carousel.carousel-slider').carousel({
	fullWidth: true
});
